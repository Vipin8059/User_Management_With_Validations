package com.geekster.User_Management_With_Validation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserManagementWithValidationApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserManagementWithValidationApplication.class, args);
	}

}
